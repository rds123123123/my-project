import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";
import Contact from "@/pages/Contact";
import BusinessContact from "@/pages/BusinessContact";
import About from "@/pages/About";
import AdminLogin from "@/pages/admin/AdminLogin";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminPosts from "@/pages/admin/AdminPosts";
import AdminPostEditor from "@/pages/admin/AdminPostEditor";
import AdminPages from "@/pages/admin/AdminPages";
import AdminPageEditor from "@/pages/admin/AdminPageEditor";
import AdminContacts from "@/pages/admin/AdminContacts";
import AdminMedia from "@/pages/admin/AdminMedia";
import { AdminLayout } from "@/pages/admin/AdminLayout";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={BlogPost} />
      <Route path="/contact" component={Contact} />
      <Route path="/business-contact" component={BusinessContact} />
      <Route path="/about" component={About} />

      {isLoading ? (
        <Route path="/admin/:rest*">
          {() => (
            <div className="flex items-center justify-center min-h-screen">
              <div className="animate-pulse text-muted-foreground">Loading...</div>
            </div>
          )}
        </Route>
      ) : !isAuthenticated ? (
        <Route path="/admin/:rest*" component={AdminLogin} />
      ) : (
        <>
          <Route path="/admin">
            {() => (
              <AdminLayout>
                <AdminDashboard />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/posts">
            {() => (
              <AdminLayout>
                <AdminPosts />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/posts/new">
            {() => (
              <AdminLayout>
                <AdminPostEditor />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/posts/:id/edit">
            {() => (
              <AdminLayout>
                <AdminPostEditor />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/pages">
            {() => (
              <AdminLayout>
                <AdminPages />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/pages/new">
            {() => (
              <AdminLayout>
                <AdminPageEditor />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/pages/:id/edit">
            {() => (
              <AdminLayout>
                <AdminPageEditor />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/contacts">
            {() => (
              <AdminLayout>
                <AdminContacts />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/media">
            {() => (
              <AdminLayout>
                <AdminMedia />
              </AdminLayout>
            )}
          </Route>
        </>
      )}

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
