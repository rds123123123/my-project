import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export function PublicNav() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const isHome = location === "/";

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navClass = `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
    isScrolled || !isHome
      ? "bg-background/95 backdrop-blur-md border-b border-border shadow-sm"
      : "bg-transparent"
  }`;

  const linkClass = `text-sm font-medium transition-colors hover-elevate px-3 py-2 rounded-md ${
    isScrolled || !isHome ? "text-foreground" : "text-white"
  }`;

  return (
    <nav className={navClass} data-testid="nav-public">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-2" data-testid="link-home">
            <span className={`text-xl font-bold font-display ${isScrolled || !isHome ? "text-foreground" : "text-white"}`}>
              CMS Platform
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-1">
            <Link href="/" className={linkClass} data-testid="link-nav-home">
              Home
            </Link>
            <Link href="/blog" className={linkClass} data-testid="link-nav-blog">
              Blog
            </Link>
            <Link href="/about" className={linkClass} data-testid="link-nav-about">
              About
            </Link>
            <Link href="/contact" className={linkClass} data-testid="link-nav-contact">
              Contact
            </Link>
            <Link href="/admin" data-testid="link-nav-admin">
              <Button variant="default" size="sm" className="ml-4">
                Admin
              </Button>
            </Link>
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            data-testid="button-mobile-menu"
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? (
              <X className={`h-6 w-6 ${isScrolled || !isHome ? "text-foreground" : "text-white"}`} />
            ) : (
              <Menu className={`h-6 w-6 ${isScrolled || !isHome ? "text-foreground" : "text-white"}`} />
            )}
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-t border-border">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link href="/" className="block px-3 py-2 text-base font-medium text-foreground hover-elevate rounded-md" data-testid="link-mobile-home">
              Home
            </Link>
            <Link href="/blog" className="block px-3 py-2 text-base font-medium text-foreground hover-elevate rounded-md" data-testid="link-mobile-blog">
              Blog
            </Link>
            <Link href="/about" className="block px-3 py-2 text-base font-medium text-foreground hover-elevate rounded-md" data-testid="link-mobile-about">
              About
            </Link>
            <Link href="/contact" className="block px-3 py-2 text-base font-medium text-foreground hover-elevate rounded-md" data-testid="link-mobile-contact">
              Contact
            </Link>
            <Link href="/admin" className="block px-3 py-2" data-testid="link-mobile-admin">
              <Button variant="default" size="sm" className="w-full">
                Admin
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
