import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Clock } from "lucide-react";
import type { Post } from "@shared/schema";

interface BlogCardProps {
  post: Post;
}

export function BlogCard({ post }: BlogCardProps) {
  const formattedDate = post.createdAt
    ? new Date(post.createdAt).toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : "";

  return (
    <Link href={`/blog/${post.slug}`} data-testid={`card-post-${post.id}`}>
      <Card className="overflow-hidden hover-elevate active-elevate-2 transition-all h-full">
        {post.featuredImage && (
          <div className="aspect-video overflow-hidden">
            <img
              src={post.featuredImage}
              alt={post.title}
              className="w-full h-full object-cover"
              data-testid={`img-post-${post.id}`}
            />
          </div>
        )}
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-2 line-clamp-2" data-testid={`text-post-title-${post.id}`}>
            {post.title}
          </h3>
          {post.excerpt && (
            <p className="text-muted-foreground text-sm mb-4 line-clamp-3" data-testid={`text-post-excerpt-${post.id}`}>
              {post.excerpt}
            </p>
          )}
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>{formattedDate}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>5 min read</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
