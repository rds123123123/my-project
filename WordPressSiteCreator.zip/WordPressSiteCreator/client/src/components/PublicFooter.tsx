import { Link } from "wouter";
import { Mail, MapPin, Phone, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function PublicFooter() {
  return (
    <footer className="bg-card border-t border-card-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold font-display mb-4" data-testid="text-footer-brand">CMS Platform</h3>
            <p className="text-muted-foreground text-sm mb-4">
              A modern content management system for creating and managing your website content with ease.
            </p>
            <div className="flex space-x-2">
              <a href="#" className="p-2 bg-secondary rounded-md hover-elevate" aria-label="Facebook" data-testid="link-social-facebook">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 bg-secondary rounded-md hover-elevate" aria-label="Twitter" data-testid="link-social-twitter">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 bg-secondary rounded-md hover-elevate" aria-label="Instagram" data-testid="link-social-instagram">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 bg-secondary rounded-md hover-elevate" aria-label="LinkedIn" data-testid="link-social-linkedin">
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-home">Home</Link></li>
              <li><Link href="/blog" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-blog">Blog</Link></li>
              <li><Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-about">About</Link></li>
              <li><Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-contact">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact Info</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>123 Business Street, Suite 100, City, State 12345</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 flex-shrink-0" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 flex-shrink-0" />
                <span>hello@cmsplatform.com</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Newsletter</h4>
            <p className="text-sm text-muted-foreground mb-4">
              Subscribe to our newsletter for updates and tips.
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="Your email"
                className="flex-1"
                data-testid="input-newsletter-email"
              />
              <Button size="sm" data-testid="button-newsletter-subscribe">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} CMS Platform. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
