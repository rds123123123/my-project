import { PublicNav } from "@/components/PublicNav";
import { PublicFooter } from "@/components/PublicFooter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { FileText, Layout, Zap, BookOpen, Mail, MapPin } from "lucide-react";
import { BlogCard } from "@/components/BlogCard";
import { useQuery } from "@tanstack/react-query";
import type { Post } from "@shared/schema";
import heroImage from "@assets/generated_images/Modern_workspace_hero_image_786b8da1.png";

export default function Landing() {
  const { data: posts = [] } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
  });

  const latestPosts = posts.filter((p) => p.status === "published").slice(0, 2);

  return (
    <div className="min-h-screen">
      <PublicNav />

      <section
        className="relative h-[80vh] flex items-center justify-center text-white"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
          <h1 className="text-5xl md:text-6xl font-bold font-display mb-6" data-testid="text-hero-title">
            Content Management Made Simple
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-white/90" data-testid="text-hero-subtitle">
            Create, manage, and publish your content with our powerful and intuitive CMS platform
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/blog">
              <Button size="lg" className="backdrop-blur-sm bg-primary/90 border-primary-border" data-testid="button-hero-explore">
                Explore Blog
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="backdrop-blur-sm bg-white/10 border-white/30 text-white hover:bg-white/20" data-testid="button-hero-contact">
                Get in Touch
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4" data-testid="text-features-title">
              Powerful Features
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage your content effectively
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card data-testid="card-feature-1">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Rich Content Editor</h3>
                <p className="text-muted-foreground">
                  Create beautiful content with our intuitive rich text editor
                </p>
              </CardContent>
            </Card>

            <Card data-testid="card-feature-2">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Layout className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Page Management</h3>
                <p className="text-muted-foreground">
                  Easily create and manage custom pages for your website
                </p>
              </CardContent>
            </Card>

            <Card data-testid="card-feature-3">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Fast & Secure</h3>
                <p className="text-muted-foreground">
                  Built with modern technology for optimal performance
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-24 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4" data-testid="text-blog-preview-title">
              Latest from Our Blog
            </h2>
            <p className="text-lg text-muted-foreground">
              Insights, tips, and updates from our team
            </p>
          </div>

          {latestPosts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {latestPosts.map((post) => (
                <BlogCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No posts yet. Check back soon!</p>
            </div>
          )}

          <div className="text-center">
            <Link href="/blog">
              <Button variant="outline" size="lg" data-testid="button-view-all-posts">
                View All Posts
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold font-display mb-4" data-testid="text-contact-title">
                Get in Touch
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
              </p>

              <form className="space-y-4" data-testid="form-contact-landing" onSubmit={(e) => {
                e.preventDefault();
                window.location.href = '/contact';
              }}>
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input id="name" placeholder="Your name" data-testid="input-landing-name" />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="your@email.com" data-testid="input-landing-email" />
                </div>
                <div>
                  <Label htmlFor="message">Message</Label>
                  <Textarea id="message" placeholder="Your message..." rows={4} data-testid="input-landing-message" />
                </div>
                <Button type="submit" size="lg" className="w-full" data-testid="button-landing-submit">
                  Go to Contact Page
                </Button>
              </form>
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">Visit Us</h3>
                      <p className="text-muted-foreground text-sm">
                        123 Business Street<br />
                        Suite 100<br />
                        City, State 12345
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">Email Us</h3>
                      <p className="text-muted-foreground text-sm">
                        hello@cmsplatform.com<br />
                        support@cmsplatform.com
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <PublicFooter />
    </div>
  );
}
