import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Mail } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Contact } from "@shared/schema";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function AdminContacts() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: contacts = [], isLoading } = useQuery<Contact[]>({
    queryKey: ["/api/contacts"],
  });

  const filteredContacts = contacts.filter((contact) =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display mb-2" data-testid="text-contacts-title">
          Contact Submissions
        </h1>
        <p className="text-muted-foreground">
          View and manage contact form submissions
        </p>
      </div>

      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search contacts..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-contacts"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8">
                    Loading...
                  </TableCell>
                </TableRow>
              ) : filteredContacts.length > 0 ? (
                filteredContacts.map((contact) => (
                  <TableRow key={contact.id} data-testid={`row-contact-${contact.id}`}>
                    <TableCell className="font-medium">{contact.name}</TableCell>
                    <TableCell>{contact.email}</TableCell>
                    <TableCell>
                      <Badge variant={contact.formType === "business" ? "default" : "secondary"}>
                        {contact.formType === "business" ? "Business" : "General"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {contact.createdAt
                        ? new Date(contact.createdAt).toLocaleDateString()
                        : "N/A"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" size="sm" data-testid={`button-view-contact-${contact.id}`}>
                            <Mail className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Contact Details</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <p className="text-sm font-medium text-muted-foreground mb-1">Name</p>
                              <p className="font-medium">{contact.name}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground mb-1">Email</p>
                              <p>{contact.email}</p>
                            </div>
                            {contact.phone && (
                              <div>
                                <p className="text-sm font-medium text-muted-foreground mb-1">Phone</p>
                                <p>{contact.phone}</p>
                              </div>
                            )}
                            {contact.subject && (
                              <div>
                                <p className="text-sm font-medium text-muted-foreground mb-1">Subject</p>
                                <p>{contact.subject}</p>
                              </div>
                            )}
                            {contact.service && (
                              <div>
                                <p className="text-sm font-medium text-muted-foreground mb-1">Service Interest</p>
                                <p>{contact.service}</p>
                              </div>
                            )}
                            <div>
                              <p className="text-sm font-medium text-muted-foreground mb-1">Message</p>
                              <p className="whitespace-pre-wrap">{contact.message}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground mb-1">Submitted</p>
                              <p>
                                {contact.createdAt
                                  ? new Date(contact.createdAt).toLocaleString()
                                  : "N/A"}
                              </p>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    {searchQuery ? "No contacts found" : "No contact submissions yet"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
