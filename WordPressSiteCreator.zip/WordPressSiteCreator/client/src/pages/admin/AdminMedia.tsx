import { Card, CardContent } from "@/components/ui/card";
import { Image as ImageIcon } from "lucide-react";

export default function AdminMedia() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display mb-2" data-testid="text-media-title">
          Media Library
        </h1>
        <p className="text-muted-foreground">
          Upload and manage your images and files
        </p>
      </div>

      <Card>
        <CardContent className="p-12 text-center">
          <div className="flex flex-col items-center justify-center">
            <div className="w-20 h-20 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <ImageIcon className="h-10 w-10 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Media Library Coming Soon</h3>
            <p className="text-muted-foreground max-w-md">
              Upload, organize, and manage your media files. This feature will be available in the next update.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
