import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";

export default function AdminLogin() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold font-display mb-2">CMS Admin</CardTitle>
          <CardDescription>
            Sign in to manage your content
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <a href="/api/login" className="block">
            <Button size="lg" className="w-full" data-testid="button-admin-login">
              <LogIn className="h-5 w-5 mr-2" />
              Sign in with Replit
            </Button>
          </a>
          <p className="text-xs text-center text-muted-foreground">
            Secure authentication powered by Replit
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
