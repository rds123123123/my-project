# Design Guidelines: WordPress-Style CMS Application

## Design Approach

**Dual Interface Strategy:**
- **Public Website**: Modern content-focused design inspired by Ghost, Medium, and modern WordPress themes
- **Admin Dashboard**: Productivity-optimized interface following Material Design principles for content management efficiency

## Core Design Elements

### Typography
**Public Website:**
- Headlines: Inter/Plus Jakarta Sans, 700 weight, 2.5rem-4rem
- Body: Inter, 400 weight, 1rem-1.125rem
- Blog content: Georgia/Lora for readability, 1.125rem, 1.7 line-height

**Admin Dashboard:**
- Interface text: Inter, 400-600 weight, 0.875rem-1rem
- Section headers: 600 weight, 1.25rem
- Data tables: 400 weight, 0.875rem

### Layout System
Use Tailwind spacing units: **2, 4, 6, 8, 12, 16, 24** for consistency
- Component padding: p-4 to p-8
- Section spacing: py-12 to py-24
- Card gaps: gap-6 to gap-8

## Public Website Components

### Homepage Layout (5-6 sections)
1. **Hero Section** (80vh): Large background image with centered headline, subtitle, primary CTA button with blurred background
2. **Features Grid**: 3-column layout (lg:grid-cols-3) showcasing CMS capabilities with icons
3. **Blog Preview**: 2-column grid of latest posts with featured images, titles, excerpts
4. **Contact Form Section**: 2-column layout - form on left, contact info/map placeholder on right
5. **Footer**: 4-column grid with sitemap, contact info, social links, newsletter signup

### Blog/Posts Pages
- Post cards: Featured image (16:9 aspect ratio), title, excerpt, read time, date
- Single post layout: max-w-prose container, large hero image, content with generous line-height
- Sidebar: Categories, recent posts, search functionality

### Contact Pages
**Two Contact Forms** (separate pages or sections):
- Form 1: General inquiry (name, email, subject, message)
- Form 2: Specific purpose (additional fields like phone, service selection)
- Form styling: Consistent with outlined inputs, proper spacing (gap-4), clear labels above inputs

## Admin Dashboard Components

### Layout Structure
- **Sidebar Navigation** (w-64): Logo, menu items with icons, user profile at bottom
- **Main Content Area**: Full remaining width, breadcrumb navigation, page-specific content
- **Top Bar**: Page title, action buttons, user dropdown

### Key Admin Views
1. **Dashboard Overview**: Stats cards grid (4 columns), recent activity, quick actions
2. **Posts Management**: Data table with columns (title, author, date, status), bulk actions, search/filter
3. **Contact Submissions**: Table view with sortable columns, detail modal, export functionality
4. **Media Library**: Grid view of uploaded images, upload dropzone, search/filter
5. **Page Editor**: Split layout - form fields on left, preview on right

### Form Elements (Admin)
- Input fields: Outlined style with focus states
- Buttons: Primary (solid), Secondary (outlined), Danger (for delete actions)
- Rich text editor: Toolbar with formatting options, clean editing area
- File upload: Drag-and-drop zone with file list

## Component Library

### Navigation
**Public**: Centered horizontal nav, transparent on hero (becomes solid on scroll), mobile hamburger menu
**Admin**: Vertical sidebar with icon + text, collapsible sections for nested items

### Cards
**Blog cards**: Rounded corners (rounded-lg), shadow on hover, image fills top portion, content padding p-6
**Dashboard cards**: Minimal borders, subtle shadows, stat number prominent (text-3xl font-bold)

### Buttons
**Public**: Large (px-8 py-3), rounded-lg, primary CTA stands out
**Admin**: Medium (px-4 py-2), rounded-md, icon + text combinations

### Data Display
**Tables**: Striped rows, hover states, sortable headers, pagination at bottom
**Forms**: Stacked labels, consistent input heights (h-10 to h-12), proper error states

## Images

### Required Images
1. **Homepage Hero**: Abstract/modern workspace image, 1920x1080px minimum, overlaid with semi-transparent gradient
2. **Feature Section Icons**: Use Heroicons for consistency (DocumentText, Cog, ChartBar, etc.)
3. **Blog Post Placeholders**: 800x450px landscape images for post previews
4. **Admin Avatar Placeholders**: Circular 40x40px user avatars

### Image Treatment
- Hero images: Subtle overlay (bg-black/40) to ensure text readability
- Blog images: Maintain aspect ratios, object-cover for consistency
- Buttons on images: Backdrop blur (backdrop-blur-sm) with semi-transparent background

## Accessibility
- Consistent focus indicators across all interactive elements
- Form labels always visible (not placeholder-dependent)
- ARIA labels for icon-only buttons
- Color contrast minimum 4.5:1 for text
- Keyboard navigation support throughout

## Responsive Breakpoints
- Mobile: Single column, stacked navigation, simplified admin sidebar
- Tablet (md): 2-column grids, condensed spacing
- Desktop (lg+): Full multi-column layouts, expanded admin sidebar